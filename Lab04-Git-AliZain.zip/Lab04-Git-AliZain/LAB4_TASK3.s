.data
    my_array: .word 42, 7, 19    # The unsorted array
    size:     .word 3            # The number of elements

.text
.globl main
main:
    #setup arguments and call the sorting function
    la   x10, my_array       #base address of array
    lw   x11, size           #length of array
    
    jal  x1, bubble_sort     #call the sort function

    # --- Code to Print the Array ---
    la   x05, my_array        # Load base address of array into a temporary register
    lw   x06, size            # Load array size
    li   x07, 0               # Initialize loop counter (i = 0)

print_loop:
    bge  x07, x06, exit        # If i >= size, we are done printing, go to exit
    
    #calculate address of my_array[i]
    slli x08, x07, 2           #multiply i by 4 (shift left logical by 2)
    add  x08, x05, x08          #add offset to base address
    
    # Load and print the integer
    lw   x09, 0(x08)           #load my_array[i] into a0 (argument register for ecall)
    li   x10, 1               #ecall code 1: print integer
    ecall
    
    #space character for readability
    li   x11, 32              #ASCII code for space (' ')
    li   x12, 11              #ecall code 11: print character
    ecall
    
    addi x07, x07, 1           #Increment counter (i++)
    j    print_loop          #Repeat for next element

exit:
    li   x13, 10              #exit program safely
    ecall

bubble_sort:
    #move stack pointer down by 16 bytes
    addi sp, sp, -16          
    
    #store registers relative to the new stack pointer
    sw   x1, 12(sp)          
    sw   x8, 8(sp)           
    sw   x9, 4(sp)           

    #length is 0, skip sorting
    beq  x11, x0, sort_end

    li   x8, 0               # i = 0
outer_loop:
    bge  x8, x11, sort_end   
    mv   x9, x8              # j = i

inner_loop:
    bge  x9, x11, inner_end  
    
    #get a[i]
    slli x28, x8, 2          
    add  x28, x10, x28       
    lw   x30, 0(x28)         
    
    #get a[j]
    slli x29, x9, 2          
    add  x29, x10, x29       
    lw   x31, 0(x29)         
    
    #descending order check: if a[i] >= a[j], skip swap
    bge  x30, x31, skip_swap 
    
    #perform swap
    sw   x31, 0(x28)         
    sw   x30, 0(x29)         
    
skip_swap:
    addi x9, x9, 1           
    j    inner_loop
    
inner_end:
    addi x8, x8, 1           
    j    outer_loop
    
sort_end:
    #restore registers from their exact stack memory addresses
    lw   x9, 4(sp)           
    lw   x8, 8(sp)           
    lw   x1, 12(sp)          
    
    #restore stack pointer 
    addi sp, sp, 16          
    jalr x0, 0(x1)