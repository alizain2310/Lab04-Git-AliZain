.data
    n: .word 4          #the Fibonacci term to calculate

.text
.globl main
main:
    lw   x10, n         #load n into argument register x10 
    jal  x1, fib        

    #print the final calculated Fibonacci number
    li   x17, 1         #ecall code for printing something
    ecall

    #exit program
    li   x17, 10        #ecall code 10 for exit
    ecall

fib:
    addi x2, x2, -12    #make room for 3 words on the stack
    sw   x1, 8(x2)      #save return address
    sw   x8, 4(x2)      #save x8 used to hold fib(n-1)
    sw   x10, 0(x2)     #save current n

    #base Case Check
    li   x5, 1          
    ble  x10, x5, fib_done  #if n <= 1, branch to end 

    #recursive Step fib(n-1)
    addi x10, x10, -1   #n = n - 1
    jal  x1, fib        #call fib(n-1)
    mv   x8, x10        #temporarily store the result of fib(n-1) in x8

    #recursive Step 2 fib(n-2)
    lw   x10, 0(x2)     #reload original n from the stack
    addi x10, x10, -2   #n = n - 2
    jal  x1, fib        #call fib(n-2)

    #combing results
    add  x10, x10, x8   #x10 = fib(n-2) + fib(n-1)

fib_done:
    #eestore state from stack
    lw   x1, 8(x2)      #restore return address
    lw   x8, 4(x2)      #restore x8
    addi x2, x2, 12     #deallocate stack space
    
    jalr x0, 0(x1)