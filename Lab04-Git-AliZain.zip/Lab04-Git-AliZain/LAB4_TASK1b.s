li   x10, 4          # Set n = 4
li x2, 1
jal  x1, fact        # Call the factorial function
ecall
fact:
    li x11, 1       #initialize acc to 1
    bge x10, x0, L2  #if n >= 0, go to L2
L2:
    mul x11, x11, x10  #acc = acc * n
    addi x10, x10, -1  #n = n - 1
    bge x10, x2, L2    #if n >= 0, repeat loop

    mv x10, x11        #move result to x10
    jalr x0, 0(x1)     #return
    